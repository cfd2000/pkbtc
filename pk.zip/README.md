# Brutus-with-fastecdsa
Brutus with fastecdsa
Brutus Bitcoin Private Key Brute Forcer with fastecdsa

Brutus with fastecdsais a modified copy of Plutus with fastecdsa from imcmurray

Origin: https://github.com/imcmurray/Plutus-fastecdsa

It is modified to generate random private keys until it fits to the given bitcoin wallet address.

To use it, you have to write the bitcoin address in line 14.

Then start it with

python3 brutus.py

Requirements for python ist fastecdsa
Try for example with with pip install fastecdsa

fastecdsa need GMP install. Example for Centos: yum install gmp-devel

Have fun with it and good luck.

Would be happy for a coffee cup donation.

Donate Bitcoin: 18caPgfTVEGgDMAaiJ6A7U9t9RnH1Yez38
 
Donate Digibyte: DFPm29NrC83LjdCYKwpu4j3zg9tQdPp1ek

Ripple: r3pBG89ZnUeFvPmMSJNVTvUvgXSHFKjyKx

ETH: 0x9aaA45e5d58a1a6fA2e6dbD651E9a08f68C9bc40
